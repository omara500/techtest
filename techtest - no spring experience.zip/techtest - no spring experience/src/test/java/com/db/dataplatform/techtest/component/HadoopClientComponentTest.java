package com.db.dataplatform.techtest.component;

import com.db.dataplatform.techtest.server.component.HadoopClient;
import com.db.dataplatform.techtest.server.component.impl.HadoopClientImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import static com.db.dataplatform.techtest.TestDataHelper.DUMMY_DATA;
import static com.db.dataplatform.techtest.server.component.impl.HadoopClientImpl.URI_PUSHBIGDATA;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.awaitility.Awaitility.await;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {HadoopClientImpl.class})
@EnableAutoConfiguration
public class HadoopClientComponentTest {

	@MockBean
	private RestTemplate restTemplateMock;

	@Autowired
	HadoopClient hadoopClient;

	@Test
	public void testHadoopClientRetryWorksAsExpected() {

		when(restTemplateMock.postForObject(eq(URI_PUSHBIGDATA), eq(DUMMY_DATA), eq(HttpStatus.class)))
				.thenThrow(new HttpServerErrorException(HttpStatus.GATEWAY_TIMEOUT));

		try {
			await().atMost(5, SECONDS).untilAsserted(() ->
				hadoopClient.saveBigData(DUMMY_DATA));
				//verify(restTemplateMock, atLeast(2)).postForObject(anyString(), anyString(), eq(HttpStatus.class));

		} catch(Exception ex){ }
	}
}
