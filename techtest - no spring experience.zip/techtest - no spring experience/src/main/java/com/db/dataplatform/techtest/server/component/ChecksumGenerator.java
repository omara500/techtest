package com.db.dataplatform.techtest.server.component;

public interface ChecksumGenerator {
    String generateChecksum(String data);
}
