package com.db.dataplatform.techtest.server.persistence;

public enum BlockTypeEnum {
    FULL("full"),
    INCREMENTAL("incremental");

    private final String type;

    BlockTypeEnum(String type) {
        this.type = type;
    }

}
