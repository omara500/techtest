package com.db.dataplatform.techtest.server.component.impl;

import com.db.dataplatform.techtest.server.component.ChecksumGenerator;
import org.springframework.stereotype.Component;

/**
 * Checksum generator component
 */
@Component
public class ChecksumGeneratorImpl implements ChecksumGenerator {

    @Override
    public String generateChecksum(String data) {
        return null;
    }
}
